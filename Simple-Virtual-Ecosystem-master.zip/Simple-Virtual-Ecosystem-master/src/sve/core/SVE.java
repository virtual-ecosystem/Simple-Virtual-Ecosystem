package sve.core;

/**
 *Main class for SVE system
 *
 *@author repelliuss
 */
public class SVE {

	public void start() {

		init();
		update();
		finish();
	}

	private void init() {
		//TODO
	}

	private void update() {
		//TODO
	}

	private void finish() {
		//TODO
	}
}
