import sve.core.SVE;

public class ScenarioCheela {

	public static void main(String[] args) {

		//TODO

		SVE sve = new SVE();

		sve.start();
	}
}
