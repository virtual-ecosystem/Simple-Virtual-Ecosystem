package sve.test.stats;

import sve.test.Test;
import sve.test.TestManager;

/**
 * Utility class to register the
 * tests of Stats module of
 * SVE system to TestManager
 *
 * @author repelliuss
 */
public class StatsTestRecorder {

	/**
	 * Register your unit tests here!
	 */
	public static void recordAll(TestManager tester) {

	}

}
