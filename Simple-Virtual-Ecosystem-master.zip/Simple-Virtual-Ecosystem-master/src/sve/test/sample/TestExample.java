package sve.test.sample;

public class TestExample {

	public static boolean exampleTest() {

		int x = 7 + 3;

		if(x == 10)
			return true;

		return false;
	}
}
