package sve.core;

/**
 * Database class of SVE
 *
 * @author repelliuss
 */
public class SVEDatabase {
    
}
