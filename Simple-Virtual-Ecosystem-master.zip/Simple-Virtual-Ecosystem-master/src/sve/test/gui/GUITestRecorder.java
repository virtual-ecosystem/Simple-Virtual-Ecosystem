package sve.test.gui;

import sve.test.TestManager;
import sve.test.Test;

/**
 * Utility class to register the
 * tests of GUI module of
 * SVE system to TestManager
 *
 * @author repelliuss
 */
public class GUITestRecorder {

	/**
	 * Register your unit tests here!
	 */
	public static void recordAll(TestManager tester) {

	}
}
