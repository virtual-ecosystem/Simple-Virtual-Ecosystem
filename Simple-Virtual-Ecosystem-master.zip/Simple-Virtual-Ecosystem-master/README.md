# Simple-Virtual-Ecosystem
SVE is a scientific program that simulates competition between communities and competition for resources.
